#Chat bot for PyChat 1.6.x

names=['HAYAMIK','v8','hugo','biribo','mandarin','doublebuble','loopy123','haotik'
       '???','MaxMin','BAKLASHAN','KOTIK_NOTIK','Tester']
frases=['Всем ку','Прив','ДА ЛАДНО!','????','всм','как дела','норм','кто хочет играть в кс','нет',':)','Ходят слухи что здесь обитают боты','Все же правила читали?','да','ххахахахахаха',':(','Ты где был','Бан хочешь?','ЛОЛ','Сабачка)','Сколько вам лет?','12','8','11',
        'О','*_*','ДАРОВА КОРОВА','За это бан не дают','ФУУУУУУУУ']
import socket, threading, time,random
key = 8194

shutdown = False
join = False
global message
message=""
print("WELCOME TO PyChat")
print(" _______              ______   __                    __     ")
print("/       \            /      \ /  |                  /  |    ")
print("$$$$$$$  | __    __ /$$$$$$  |$$ |____    ______   _$$ |_   ")
print("$$ |__$$ |/  |  /  |$$ |  $$/ $$      \  /      \ / $$   |  ")
print("$$    $$/ $$ |  $$ |$$ |      $$$$$$$  | $$$$$$  |$$$$$$/   ")
print("$$$$$$$/  $$ |  $$ |$$ |   __ $$ |  $$ | /    $$ |  $$ | __ ")
print("$$ |      $$ \__$$ |$$ \__/  |$$ |  $$ |/$$$$$$$ |  $$ |/  |")
print("$$ |      $$    $$ |$$    $$/ $$ |  $$ |$$    $$ |  $$  $$/ ")
print("$$/        $$$$$$$ | $$$$$$/  $$/   $$/  $$$$$$$/    $$$$/  ")
print("          /  \__$$ |  ")                                      
print("          $$    $$/  ")                                       
print("           $$$$$$/")                                          
print("By: Tikhon Sherstobitov")

def receving (name, sock):
        while not shutdown:
                try:
                        while True:
                                data, addr = sock.recvfrom(1024)
                                print(data.decode("utf-8"))

                                # Begin
                                decrypt = ""; k = False
                                for i in data.decode("utf-8"):
                                        if i == ":":
                                                k = True
                                                decrypt += i
                                        elif k == False or i == " ":
                                                decrypt += i
                                        else:
                                                decrypt += chr(ord(i)^key)
                                
                                if data.decode("utf-8") == '/banned':
                                     print('You has banned on this server!')
                                     rT.join()
                                     s.close()
                                     exit()
                                if data.decode('utf-8') == 'Всем ку':
                                        a=random(0,1)
                                        if a==0:
                                           b=random(1,4)
                                           if b == 1:
                                                message='Прив'
                                           if b == 2:
                                                message='Ку'
                                           if b == 3:
                                                message='ДАРОВА КОРОВА'
                                           if b == 4:
                                                message='как дела?'
                                        print('dg')
                                        if a==1:
                                           message=frases[random(0,len(frases)-1)]
                                if data.decode('utf-8') == 'кто хочет играть в кс':
                                        a=random(0,1)
                                        if a==0:
                                           b=random(1,4)
                                           if b == 1:
                                                message='ФУУУУУ'
                                           if b == 2:
                                                message='нет'
                                           if b == 3:
                                                message='да'
                                           if b == 4:
                                                message=':)'
                                        print('dg')
                                        if a==1:
                                           message=frases[random(0,len(frases)-1)]
                                if data.decode('utf-8') == 'сколько вам лет':
                                        a=random(0,1)
                                        if a==0:
                                           b=random(1,4)
                                           if b == 1:
                                                message='10'
                                           if b == 2:
                                                message='8'
                                           if b == 3:
                                                message='12'
                                           if b == 4:
                                                message='лет омлет'
                                        print('dg')
                                        if a==1:
                                           message=frases[random(0,len(frases)-1)]
                                if data.decode('utf-8') == 'Ходят слухи что здесь обитают боты':
                                        a=random(0,1)
                                        if a==0:
                                           b=random(1,4)
                                           if b == 1:
                                                message='ДА ЛАДНО'
                                           if b == 2:
                                                message='ЛОЛ'
                                           if b == 3:
                                                message='*_*'
                                           if b == 4:
                                                message=':)'
                                        print('dg')
                                        if a==1:
                                           message=frases[random(0,len(frases)-1)]
                                if data.decode('utf-8') == 'как дела':
                                        a=random(0,1)
                                        if a==0:
                                           b=random(1,4)
                                           if b == 1:
                                                message='норм'
                                           if b == 2:
                                                message='О'
                                           if b == 3:
                                                message='ЛОЛ'
                                           print('dg')
                                        if a==1:
                                           message=frases[random(0,len(frases)-1)]
                                otvet=open('otvet.txt','w')
                                otvet.write(message)
                                otvet.close()
                                
                                print(decrypt)
                                # End

                                time.sleep(0.2)
                except:
                        pass
host = socket.gethostbyname(socket.gethostname())
port = 0

getip = ""
getport = ""
'''
ct=input("Custom setings/Standart setings(Only for test!)?:")

if ct == "Custom setings":
        print("test ip = 127.0.1.1")
        getip = input("server IP = ")
        print("test port = 9090")
        getport = input("Server Pprt = ")
if ct == "Standart setings":
        getip = "127.0.1.1"
        getport = 9090
server = (str(getip),int(getport))
'''
count = 1
server_list = open('server.txt')
for server in server_list.readlines():
        print(str(count)+'. Name: '+' Ip:'+server.split('=')[1]+' Port:'+server.split('=')[2])
        count=count+1
ct = input('Serer:')
getip = server.split('=')[1]
getport = server.split('=')[2]
s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
s.bind((host,port))
s.setblocking(0)

alias = names[random.randint(0,len(names)-1)]

server = (str(getip),int(getport))

rT = threading.Thread(target = receving, args = ("RecvThread",s))
rT.start()

while shutdown == False:
        if join == False:
                s.sendto(("["+alias + "] => join chat ").encode("utf-8"),server)
                join = True
                '''
                message=input('>')
                otvet=open('otvet.txt','w')
                otvet.write(message)
                otvet.close()
                '''
        else:
                try:
                        '''
                        otvet=open('otvet.txt')
                        message=otvet.read()
                        otvet.close()
                        '''
                        message=frases[random.randint(0,len(frases)-1)]
                        tt=random.randint(4,10)
                        # Begin
                        #message=message.encode('utf-8')
                        if message == '/banned':
                                print('You has banned on this server!')
                                rT.join()
                                s.close()
                                shutdown = True
                        # End

                        if message != "":
                                s.sendto(("["+alias + "] :: "+message).encode("utf-8"),server)
                        
                        time.sleep(0)
                except:
                        s.sendto(("["+alias + "] <= left chat ").encode("utf-8"),server)
                        shutdown = True

rT.join()
s.close()
